# Make sure to put the file in the right place
# Also remember common_mytkrplot.r is used elsewhere (tk binary GUI)
# It may not be wise to have different versions
# Although it should be fairly stable

##############################################
#         selectPgonMap() function
#       returns a list with the x and y of the selection pgon
#      shp.file: full path to a shape file to be used as basemap
##############################################
selectPgonMap<-function(shp.file){
    requireNamespace("rgdal",quietly=TRUE)
    GCDmap<<-NULL
    setwd(earthchem.dir)
    loadData(shp.file)
    palette<-"terrain.colors"
    GCDmap<-get("GCDmap",.GlobalEnv)
    flush.console()
    map.col<-selectPalette(length(GCDmap[[1]]),palette)
    
    graphics.off()
    win.metafile()
    
    #sheet<-get("sheet",.GlobalEnv)
    xMinExtd<-sheet$demo$call$xlim["min"]
    xMaxExtd<-sheet$demo$call$xlim["max"]
    yMinExtd<-sheet$demo$call$ylim["min"]
    yMaxExtd<-sheet$demo$call$ylim["max"]

    assign("pgon.x",NULL,.GlobalEnv)
    assign("pgon.y",NULL,.GlobalEnv)

    ##############################################
    #         Plotting function                   
    ##############################################
    make.map<-function(){
        old.bg<-par()$bg
        par(bg="white")
        sheet<-get("sheet",.GlobalEnv)
        xMin<-sheet$demo$call$xlim["min"]
        xMax<-sheet$demo$call$xlim["max"]
        yMin<-sheet$demo$call$ylim["min"]
        yMax<-sheet$demo$call$ylim["max"]
                
        # Add a polygon 
        get("pgon.x",envir=.GlobalEnv)
        get("pgon.y",envir=.GlobalEnv)
        
        #if(!is.null(pgon.x)) windows(6*1.585,6) # Debugging
        plot(GCDmap[[1]],col=map.col,axes=TRUE,xaxs="i",yaxs="i",add=FALSE,longlat=FALSE,xlim=c(xMin,xMax),ylim=c(yMin,yMax),type="n")          
        
        if(length(pgon.x)==1){
            points(pgon.x,pgon.y,col="red",pch=19)
        }
        
        if(length(pgon.x)==2){
            lines(pgon.x,pgon.y,col="red",lwd=2)
        }
        
        if(length(pgon.x)>2){
            polygon(pgon.x,pgon.y,border="red",lty="solid",lwd=2,density=5,angle=45,add=TRUE)
        }
        
            
        # Bounding box for debugging
        xMin<-map.img$mapx[2]
        xMax<-map.img$hpix-map.img$mapx[4]-map.img$mapx[2]
        yMax<-map.img$vpix-map.img$mapx[3]-map.img$mapx[1]
        yMin<-map.img$mapx[1]
        
        xRange<-sheet$demo$call$xlim  
        yRange<-sheet$demo$call$ylim
        
        xx<-xRange[1]+(xRange[2]-xRange[1])*(c(xMin,xMax)-xMin)/(xMax-xMin)
        yy<-yRange[1]+(yRange[2]-yRange[1])*(c(yMin,yMax)-yMin)/(yMax-yMin)
        # Debugging
        #polygon(c(xx[1],xx[2],xx[2],xx[1],xx[1]),c(yy[1],yy[1],yy[2],yy[2],yy[1]),border="green")
        # END
                
        par(bg=old.bg)
    }
 
    ##############################################
    #         React to a click in the map         
    ##############################################

    ### Convert widget coordinates to graph coordinates
    #.PxToGraphCoords<-function(xpx,ypx){
    #
    ## Graph coordinates
    #
    #xMinPx<-map.img$mapx[2]
    #xMaxPx<-map.img$hpix-map.img$mapx[4]
    #yMinPx<-map.img$vpix-map.img$mapx[1]
    #yMaxPx<-map.img$mapx[3]
    #
    #xMin<-sheet$demo$call$xlim["min"]
    #xMax<-sheet$demo$call$xlim["max"]
    #yMin<-sheet$demo$call$ylim["min"]  
    #yMax<-sheet$demo$call$ylim["max"]
    #
    #xgraph<-xMin+(xMax-xMin)*(xpx-xMinPx)/(xMaxPx-xMinPx)
    #ygraph<-yMin+(yMax-yMin)*(ypx-yMinPx)/(yMaxPx-yMinPx)
    #
    #res<-c(xgraph,ygraph)
    #names(res)<-NULL
    #return(res)
    #}

    ### Not used -- for testing purposes
    .OnLeftClick.test <- function(x,y){
        # Pixel coordinates      
        xClick <- as.numeric(x)
        yClick <- as.numeric(y)
        #cat("Click at X=",xClick," ; Y=",yClick,"\n") 

        ee<-.PxToGraphCoords(xClick,yClick,map.img)
        xPlotCoord<-ee[1] 
        yPlotCoord<-ee[2]
        
        #cat("Graph coordinates X=",xPlotCoord," ; Y=",yPlotCoord,"\n") 
    }

    OnLeftClick<-function(x,y){
        switch(tclvalue(t.sel),
            "in"=Zoom(x,y,0.5),
            "out"=Zoom(x,y,2),
            "cent"=Zoom(x,y,1), 
            "sel"=SelectPgon(x,y))     
    }

    ##############################################
    #                  Actions                    
    ##############################################

    Zoom<-function(x,y,zf){    
        x<-as.numeric(x)
        y<-as.numeric(y)
        
        #print(c(x,y))
        ee<-.PxToGraphCoords(x,y,map.img)
        #cat("zoom, zf=",zf,"x=",ee[1],"y=",ee[2],"\n")
        
        map.w<-sheet$demo$call$xlim["max"]-sheet$demo$call$xlim["min"]
        map.h<-sheet$demo$call$ylim["max"]-sheet$demo$call$ylim["min"]
        
        # Correction by VJ, points were slightly off
        #map.w<-diff(par()$usr[1:2])
        #map.h<-diff(par()$usr[3:4])
        
        #print("Ranges before zooming")
        #cat(map.w,map.h,"\n")
        #print("Centre")
        #cat(ee,"\n")
        
        xmin<-ee[1]-map.w*zf/2
        xmax<-ee[1]+map.w*zf/2
        ymin<-ee[2]-map.h*zf/2
        ymax<-ee[2]+map.h*zf/2
        
        #xmin.prov<-ee[1]-map.w*zf/2
        #xmax.prov<-ee[1]+map.w*zf/2
        #ymin.prov<-ee[2]-map.h*zf/2
        #ymax.prov<-ee[2]+map.h*zf/2
        #cat(xmin.prov,xmax.prov,ymin.prov,ymax.prov,"\n")
        
        #xmin<-max(xMinExtd,xmin.prov)
        #xmax<-min(xMaxExtd,xmax.prov)
        #ymin<-max(yMinExtd,ymin.prov)
        #ymax<-min(xMaxExtd,ymax.prov)
        
        #print("Coords after zooming")
        #cat(xmin,xmax,ymin,ymax,"\n")
        
        sheet$demo$call$xlim["min"]<-xmin
        sheet$demo$call$xlim["max"]<-xmax
        sheet$demo$call$ylim["min"]<-ymin
        sheet$demo$call$ylim["max"]<-ymax
        assign("sheet",sheet,.GlobalEnv)
        tkrreplot.px(map.img)
    }

    SelectPgon<-function(x,y){
        ee<-.PxToGraphCoords(as.numeric(x),as.numeric(y),map.img)
        get("pgon.x",envir=.GlobalEnv)
        get("pgon.y",envir=.GlobalEnv)
        
        pgon.x<-c(pgon.x,ee[1])
        pgon.y<-c(pgon.y,ee[2])
         
        assign("pgon.x",pgon.x,.GlobalEnv)
        assign("pgon.y",pgon.y,.GlobalEnv)
        #cat("Coords[",ee[1],",",ee[2],"]\n",sep="")
        tkrreplot.px(map.img)
    }

    ##############################################
    #            Actions on buttons               
    ##############################################
    clear.pgon<-function(){
        assign("pgon.x",NULL,.GlobalEnv)
        assign("pgon.y",NULL,.GlobalEnv)
        tkrreplot.px(map.img) 
    }
 
    onQuit<-function(){
        tkdestroy(tmap)
        tkraise(tt)
    }

    ##############################################
    #         Build interface                     
    ##############################################

    ### Top-level
    tmap<-tktoplevel()
    tkwm.title(tmap,"Map of the World")

    ### Map 
    # Not used, but could be used to fit the window to the screen if required...
    #GUI.AvailableScreenWidth <- round(as.numeric(tkwinfo("screenwidth", 
    #        tmap)))/2
    #GUI.AvailableScreenHeight <- round(as.numeric(tkwinfo("screenheight", 
    #        tmap)))/2
    
    #hv<-1
    hv<- 1.585   ## Empirical, looks good like that! Real aspekt ratio is 1.960532
    vert<-500
    #vert<-GUI.AvailableScreenHeight
    hrz<-vert*hv    
    #hrz<-GUI.AvailableScreenWidth
    
    map.frame<- ttklabelframe(tmap, text="")
    map.img <<- tkrplot.px(map.frame,fun=make.map,hpix=hrz,vpix=vert)
    tkbind(map.img,"<Button-1>",OnLeftClick)

    ### Alternative bindings
    # Left here, but beware - both single and double click are binded so both actions
    # will occur on double click...

    OnRightClick<-function(x,y){
        Zoom(x,y,2)
    }
    tkbind(map.img,"<Button-3>",OnRightClick)

    OnDoubleClick<-function(x,y){
        Zoom(x,y,0.5)
    }
    tkbind(map.img,"<Double-Button-1>",OnDoubleClick)

    ### Radio buttons
    tool.frame <- ttklabelframe(tmap, text="Select tool")

    tb1 <- ttkradiobutton(tool.frame)
    tb2 <- ttkradiobutton(tool.frame)
    tb3 <- ttkradiobutton(tool.frame)
    tb4 <- ttkradiobutton(tool.frame)

    t.sel <- tclVar("sel")

    foo<-function(){}
    tkconfigure(tb1,variable=t.sel,value="in",command=function() foo())
    tkconfigure(tb2,variable=t.sel,value="out",command=function() foo())
    tkconfigure(tb3,variable=t.sel,value="cent",command=function() foo())
    tkconfigure(tb4,variable=t.sel,value="sel",command=function() foo())

    tb1.lab<-tklabel(tool.frame,text="Zoom in")
    tb2.lab<-tklabel(tool.frame,text="Zoom out")
    tb3.lab<-tklabel(tool.frame,text="Center")
    tb4.lab<-tklabel(tool.frame,text="Select")

    ### Big buttons
    clear.but<-tkbutton(tool.frame,text="Clear",command=function() clear.pgon())
    ok.but<-tkbutton(tool.frame,text="Ok",command=function() onQuit())

    ### Grid
    tkgrid(map.frame,tool.frame)
    tkgrid(map.img)
    tkgrid(tb1,tb1.lab)
    tkgrid(tb2,tb2.lab)
    tkgrid(tb3,tb3.lab)
    tkgrid(tb4,tb4.lab)

    tkgrid(clear.but,ok.but)

    tkwait.window(tmap)
    tkfocus(tt)
    return(list(x=pgon.x,y=pgon.y))
}     # end of selectPgonMap()

##### Usage
# library(rgdal)
# qq<-selectPgonMap("world_country_admin_boundary_shapefile_with_fips_codes.shp")
