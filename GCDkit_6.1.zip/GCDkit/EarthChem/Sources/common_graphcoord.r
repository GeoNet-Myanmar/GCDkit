#########################################################
#         Convert widget coordinates to graph coordinates
#########################################################

.PxToGraphCoords<-function(xpx,ypx,theplot,logX=F,logY=FALSE){
    # Graph coordinates
    xMin<-theplot$mapx[2]
    xMax<-theplot$hpix-theplot$mapx[4]
    yMin<-theplot$vpix-theplot$mapx[1]
    yMax<-theplot$mapx[3]
    
    sheet<-get("sheet",.GlobalEnv)
    xRangeUser<-sheet$demo$call$xlim 
    yRangeUser<-sheet$demo$call$ylim
    
    # Correction by VJ, points were slightly off
    #xRangeUser<-par()$usr[1:2]
    #yRangeUser<-par()$usr[3:4]
    
    #x<-grconvertX(xpx,from="nic",to="device")
    #y<-grconvertX(as.numeric(y),from="nic",to="device")
      
    if(logX){
        lxgraph<-log10(xRangeUser[1])+(log10(xRangeUser[2])-log10(xRangeUser[1]))*(xpx-xMin)/(xMax-xMin)
        xgraph<-10^lxgraph
    }else{
        xgraph<-xRangeUser[1]+(xRangeUser[2]-xRangeUser[1])*(xpx-xMin)/(xMax-xMin)
    }

    if(logY){
        lygraph<-log10(yRangeUser[1])+(log10(yRangeUser[2])-log10(yRangeUser[1]))*(ypx-yMin)/(yMax-yMin)
        ygraph<-10^lygraph
    }else{
        ygraph<-yRangeUser[1]+(yRangeUser[2]-yRangeUser[1])*(ypx-yMin)/(yMax-yMin)
    }
    #cat("Click at",xpx,ypx,"\n")
     
    res<-c(xgraph,ygraph)
    #cat("Device coordinates OL",res,"\n")
    names(res)<-NULL
    return(res)
}
