###############################################################################
#                   Classification of bophioloitic basalts                    #
#  Saccani, E. (2015): A new method of discriminating different types of      #
#  post-Archean ophiolitic basalts and their tectonic significance using      #
#  Th-Nb and Ce-Dy-Yb systematics. � Geoscience Frontiers 6, 481�501.         #
###############################################################################


# Fig. 5a
Saccani<-function(plot.txt=getOption("gcd.plot.text")){
    if(!getOption("gcd.plot.bw")){
        col1<-plt.col[3]
        col2<-plt.col[2]
    }else{
        col1<-"black"
        col2<-"black"
    }
    
    x.data<<-WR[,"Nb"]/2.33 # NMORB of Sun and McDonough 1989
    y.data<<-WR[,"Th"]/0.12 # NMORB of Sun and McDonough 1989

    temp1<-list(
        lines1=list("lines",x=c(0.01,2.2),y=c(20,8),col=col2),
        lines2=list("lines",x=c(0.01,0.306,100),y=c(0.1,0.708,1000),col=col2),
        lines3=list("lines",x=c(0.306,0.5),y=c(0.708,0.001),col=col2),
        points1=list("points",x=0.306,y=0.708,pch=16,col=col1,cex=2),
        arrows1=list("arrows",x0=0.1,y0=0.015,x1=2,y1=0.015,code=3,col=col1,angle=30,length=0.15,lty="solid",lwd=2),
        GCDkit=list("NULL",plot.type="binary",plot.position=200.5,plot.name="NbN - ThN (Saccani 2015)")
    )  
    
    temp2<-list(      
        text5=list("text",x=2.1,y=0.013,text="DIVERGENT PLATE &\nWITHIN-PLATE SETTINGS",cex=0.8,col=col1,adj=c(0,0)),
        text6=list("text",x=0.09,y=0.013,text="CONVERGENT\nPLATE SETTINGS",cex=0.8,col=col1,adj=c(1,0)),
        text7=list("text",x=0.2,y=17.5,text="V o l c a n i c   A r c   A r r a y",cex=1.5,col=col1,adj=c(0.5,0.5),srt=40),
        text8=list("text",x=2.89,y=3.55,text="M O R B - O I B  A r r a y",cex=1.5,col=col1,adj=c(0.5,0.5),srt=40),
        text9=list("text",x=0.35,y=0.708,text="PM",col=col1,adj=0),
        text10=list("text",x=0.8,y=40,text="Continental margin\nvolcanic arc & \npolygenetic crust\nisland arc",col=col2,adj=c(0,1),srt=40),
        text10=list("text",x=0.26,y=2.74,text="forearc &\nintra-arc",col=col2,adj=c(0.5,0.5),srt=40),
        text10=list("text",x=0.03,y=0.12,text="nascent forearc",col=col2,adj=c(0.5,0.5),srt=22)
    )

    if(getOption("gcd.plot.text")) temp<-c(temp1,temp2) else temp<-temp1
       
        
    sheet<<-list(demo=list(fun="plot", 
                       call=list(xlim=c(0.01,100),
                                 ylim=c(0.01,1000),
                                 log="xy",
                                 col="green",
                                 bg="transparent",
                                 fg="black",
                                 xlab=annotate("Nb[N]"),
                                 ylab=annotate("Th[N]"),
                                 main=annotate("NbN - ThN (Saccani 2015)")),
                       template=temp))
}
