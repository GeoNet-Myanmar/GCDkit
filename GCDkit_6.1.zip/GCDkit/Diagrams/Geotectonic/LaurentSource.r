#####################################################################
#                 FSMB diagram - Laurent et al. (2014)              #
#                                                                   #
#####################################################################

LaurentSource<-function(){
    aa<-WR[,"Al2O3"]/(WR[,"FeOt"]+WR[,"MgO"])
    bb<-3*WR[,"CaO"]
    cc<-5*WR[,"K2O"]/WR[,"Na2O"]
    suma<-aa+bb+cc
    aa<-aa/suma
    bb<-bb/suma
    cc<-cc/suma
    x.data<<-cc+bb/2
    y.data<<-sqrt(3)*bb/2


    temp1<-list(
        lines1=list("lines",x=c(0,1,.5,0),y=c(0,0,sqrt(3)/2,0),col="black"),
        lines2=list("lines",x=c(0.35/2,0.4+0.35/2),y=c(sqrt(3)*0.35/2,sqrt(3)*0.35/2),col="black"),
        lines3=list("lines",x=c(0.4,0.4+0.6/2),y=c(0,sqrt(3)*0.6/2),col="black"),
        lines4=list("lines",x=c(0.2+0.35/2,0.2+0.6/2,1/2),y=sqrt(3)*c(0.35/2,0.6/2,1/2),col="black"),
        
        arrows1=list("arrows",x0=0.23,y0=0.54,x1=0.285,y1=0.464,code=2,col="darkgray",angle=30,length=0.1,lty="solid",lwd=1),
        arrows2=list("arrows",x0=0.04,y0=0.22,x1=0.133,y1=0.204,code=2,col="darkgray",angle=30,length=0.1,lty="solid",lwd=1),
        arrows3=list("arrows",x0=0.735,y0=0.59,x1=0.644,y1=0.56,code=2,col="darkgray",angle=30,length=0.1,lty="solid",lwd=1),
        arrows4=list("arrows",x0=0.91,y0=0.298,x1=0.864,y1=0.209,code=2,col="darkgray",angle=30,length=0.1,lty="solid",lwd=1),
        
        A=list("text",x=0.1,y=-0.025,text=annotate("Al2O3/(FeOt + MgO)"),adj=0.5),
        B=list("text",x=0.5,y=sqrt(3)/2+.03,text="3 CaO",adj=0.5),
        C=list("text",x=0.95,y=-0.025,text=annotate("5 K2O/Na2O"),adj=0.5),
        GCDkit=list("NULL",plot.type="ternary",plot.position=101.6,plot.name="Source diagram (Laurent et al. 2014)")
    )
        
    temp2<-list(
        text1=list("text",x=0.12,y=0.25,adj=1,text="Tonalites",col=plt.col[2],font=3),
        text2=list("text",x=1,y=0.36,adj=1,text="Meta-\nsediments",col=plt.col[2],font=3),
        text3=list("text",x=0.32,y=0.60,adj=1,text="Low-K\nmafic rocks",col=plt.col[2],font=3),
        text4=list("text",x=0.73,y=0.60,adj=0,text="High-K\n mafic rocks",col=plt.col[2],font=3)
    )

    if(getOption("gcd.plot.text")){
        temp<-c(temp1,temp2)
    }else{
        temp<-temp1
    }
    
    temp.tick<-list()
    inter<-seq(0.1,0.9,by=0.1)
    for(i in seq(1,1/0.1-1,by=1)){
        ee<-list(
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+1,"<-list(\"lines\",x=c(",inter[i]/2,",",inter[i]/2+0.030,"),y=c(",sqrt(3)*inter[i]/2,",",sqrt(3)*inter[i]/2,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+2,"<-list(\"lines\",x=c(",inter[i]/2,",",inter[i]/2+0.015,"),y=c(",sqrt(3)*inter[i]/2,",",sqrt(3)*inter[i]/2-sqrt(3)*0.015,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+3,"<-list(\"lines\",x=c(",1-inter[i]+inter[i]/2,",",1-inter[i]+inter[i]/2-0.030,"),y=c(",sqrt(3)*inter[i]/2,",",sqrt(3)*inter[i]/2,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+4,"<-list(\"lines\",x=c(",1-inter[i]+inter[i]/2,",",1-inter[i]+inter[i]/2-0.015,"),y=c(",sqrt(3)*inter[i]/2,",",sqrt(3)*inter[i]/2-sqrt(3)*0.015,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+5,"<-list(\"lines\",x=c(",inter[i],",",inter[i]+0.015,"),y=c(0,",sqrt(3)*0.015,"),col=\"black\",lwd=1,lty=1)",sep=""))),
            eval(parse(text=paste("temp.tick$ticklines",7*(i-1)+6,"<-list(\"lines\",x=c(",inter[i],",",inter[i]-0.015,"),y=c(0,",sqrt(3)*0.015,"),col=\"black\",lwd=1,lty=1)",sep="")))
        )
    }

    temp<-c(temp,temp.tick)
    sheet<<-list(demo=list(fun="plot",call=list(xlim=c(-.03,1.03),ylim=c(-0.05,1.03),main=annotate("Source diagram (Laurent et al. 2014)"),xlab="",ylab="",bg="transparent",fg="black",asp=1,axes=FALSE),template=temp))
}
