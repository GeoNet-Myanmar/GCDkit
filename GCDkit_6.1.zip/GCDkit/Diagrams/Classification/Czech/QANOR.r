#####################################################################
#             Streckeisen and Le Maitre (1979) Q'-ANOR              #
#                                                                   #
#####################################################################

QANOR<-function(mesonorm=NULL,new=TRUE){

    on.exit(options(show.error.messages = TRUE))
    options(show.error.messages = FALSE)
    
    if(is.null(mesonorm)){
        if(!diagram.testing){ #  So businness as usual
            cat("Mesonorm is to be calculated....\n")
            mesonorm<-Mesonorm(WR,GUI=FALSE)
        }else{
            # Do not calculate CIPW norm upon GCDkit startup, just dummy data
            Q<-1
            ANOR<-1
        }
    }
    
    Q<-100*mesonorm[,"Quartz"]/(mesonorm[,"Quartz"]+mesonorm[,"Orthoclase"]+mesonorm[,"Albite"]+mesonorm[,"Anorthite"])
    ANOR<-100*mesonorm[,"Anorthite"]/(mesonorm[,"Orthoclase"]+mesonorm[,"Anorthite"])
    
    x.data<<-ANOR
    y.data<<-Q
    
    ee<-cbind(Q,ANOR)
    assign("results",ee,.GlobalEnv)
    
    # Classification
    temp0<-list(
            clssf=list("NULL",
                    use=2:19, #19
                    rcname=c("2 alkali feldspar granite","3a granite","3b granite","4 granodiorite","5a tonalite","5b tonalite",
                    "6* quartz alkali feldspar syenite","7* quartz syenite","8* quartz monzonite","9* quartz monzodiorite/quartz monzogabbro","10a* quartz diorite/quartz gabbro","10b* quartz diorite/quartz gabbro",
                    "6 alkali feldspar syenite","7 syenite","8 monzonite","9 monzodiorite/monzogabbro","10a diorite/gabbro","10b diorite/gabbro")
                ),
                #Row 1
                polygon2 =list("NULL",x=c(-0.1,12.5,5,-0.1,-0.1),y=c(20,20,50.1,50.1,20)),
                polygon3a=list("NULL",x=c(12.5,22.4,8,5,12.5),y=c(20,20,50.1,50.1,20)),
                polygon3b=list("NULL",x=c(22.4,40,25,8,22.4),y=c(20,20,50.1,50.1,20)),
                polygon4 =list("NULL",x=c(40,62,50,25,40),y=c(20,20,50.1,50.1,20)),
                polygon5a=list("NULL",x=c(62,81.8,72.5,50,62),y=c(20,20,50.1,50.1,20)),
                polygon5b=list("NULL",x=c(81.8,100.1,100.1,72.5,81.8),y=c(20,20,50.1,50.1,20)),
                #Row 2
                polygon6s = list("NULL",x=c(-0.1,16.25,12.5,-0.1,-0.1),y=c(5,5,20,20,5)),
                polygon7s = list("NULL",x=c(16.25,29.6,22.4,12.5,16.25),y=c(5,5,20,20,5)),
                polygon8s = list("NULL",x=c(29.6,47.5,40,22.4,29.6),y=c(5,5,20,20,5)),
                polygon9s = list("NULL",x=c(47.5,68,62,40,47.5),y=c(5,5,20,20,5)),
                polygon10as=list("NULL",x=c(68,86.45,81.8,62,68),y=c(5,5,20,20,5)),
                polygon10bs=list("NULL",x=c(86.45,100.1,100.1,81.8,86.45),y=c(5,5,20,20,5)),
                #Row 3
                polygon6 = list("NULL",x=c(-0.1,17.5,16.25,-0.1,-0.1),y=c(-0.1,-0.1,5,5,-0.1)),
                polygon7 = list("NULL",x=c(17.5,32,29.6,16.25,17.5),y=c(-0.1,-0.1,5,5,-0.1)),
                polygon8 = list("NULL",x=c(32,50,47.5,29.6,32),y=c(-0.1,-0.1,5,5,-0.1)),
                polygon9 = list("NULL",x=c(50,70,68,47.5,50),y=c(-0.1,-0.1,5,5,-0.1)),
                polygon10a=list("NULL",x=c(70,88,86.45,68,70),y=c(-0.1,-0.1,5,5,-0.1)),
                polygon10b=list("NULL",x=c(88,100.1,100.1,86.45,88),y=c(-0.1,-0.1,5,5,-0.1)),
                GCDkit=list("NULL",plot.type="binary",plot.position=38.5,plot.name="Q-ANOR plot (Streckeisen + Le Maitre 1979)")
            )

    # Graph lines
    temp1<-list(
        lines1=list("abline",h=5,col=plt.col[2]),
        lines2=list("abline",h=20,col=plt.col[2]),
        lines3=list("lines",x=c(70,50),y=c(0,50),col=plt.col[2]),
        lines4=list("lines",x=c(50,40,25),y=c(0,20,50),col=plt.col[2]),
        lines5=list("lines",x=c(50,40,25),y=c(0,20,50),col=plt.col[2]),
        lines6=list("lines",x=c(17.5,10,5),y=c(0,30,50),col=plt.col[2]),
        lines7=list("lines",x=c(32,29.6,8),y=c(0,5,50),col=plt.col[2]),
        lines8=list("lines",x=c(88,72.5),y=c(0,50),col=plt.col[2],lty="dashed")
    )
        
    # Labels    
    temp2<-list(
        text1=list("text",x=5,y=25,text="(2)",col=plt.col[3]),
        text2=list("text",x=15,y=25,text="(3a)",col=plt.col[3]),
        text3=list("text",x=28,y=25,text="(3b)",col=plt.col[3]),
        text4=list("text",x=50,y=25,text="(4)",col=plt.col[3]),
        text5=list("text",x=70,y=25,text="(5a)",col=plt.col[3]),
        text6=list("text",x=90,y=25,text="(5b)",col=plt.col[3]),

        text7=list("text",x=7,y=13,text="(6*)",col=plt.col[3]),
        text8=list("text",x=20,y=13,text="(7*)",col=plt.col[3]),
        text9=list("text",x=35,y=13,text="(8*)",col=plt.col[3]),
        text10=list("text",x=55,y=13,text="(9*)",col=plt.col[3]),
        text11=list("text",x=75,y=13,text="(10a*)",col=plt.col[3]),
        text12=list("text",x=92,y=13,text="(10b*)",col=plt.col[3]),

        text13=list("text",x=9,y=2.5,text="(6)",col=plt.col[3]),
        text14=list("text",x=25,y=2.5,text="(7)",col=plt.col[3]),
        text15=list("text",x=40,y=2.5,text="(8)",col=plt.col[3]),
        text16=list("text",x=58,y=2.5,text="(9)",col=plt.col[3]),
        text17=list("text",x=78,y=2.5,text="(10a)",col=plt.col[3]),
        text18=list("text",x=95,y=2.5,text="(10b)",col=plt.col[3])
        )

    if(getOption("gcd.plot.text")){
        temp<-c(temp0,temp1,temp2)
    }else{
        temp<-c(temp0,temp1)
    }

    sheet<<-list(demo=list(fun="plot", call=list(xlim=c(0,100),ylim=c(0,50),col="green",bg="white",fg="black",xlab="ANOR",ylab="Q'",xaxs="r",yaxs="r"),template=temp))
    
    invisible(ee)
}
