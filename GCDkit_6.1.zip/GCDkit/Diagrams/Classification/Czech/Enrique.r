#####################################################################
#            (or+ab)-2Q-4an diagram - Enrique (2018)                #
#####################################################################
Enrique<-function(){
    if(!getOption("gcd.plot.bw")){
        col1<-plt.col[3]
        col2<-plt.col[2]
    }else{
        col1<-"black"
        col2<-"black"
    }
    
    norma<-CIPW(WR)
    norma[is.na(norma)]<-0
    
    # Conversions of names of mesonormative mins
    #colnames(norma)<-substr(colnames(norma),1,2)
    #colnames(norma)<-gsub("Qu","Q",colnames(norma))
    #colnames(norma)<-gsub("Al","Ab",colnames(norma))
    
    aa<-norma[,"Or"]+norma[,"Ab"]
    bb<-norma[,"Q"]*2
    cc<-norma[,"An"]*4
    
    results<-cbind(aa,bb,cc)
    colnames(results)<-c("or+ab","2Q","4an")
    assign("results",results,.GlobalEnv)
    
    sums<-aa+bb+cc
    
    aa<-aa/sums*100
    bb<-bb/sums*100
    cc<-cc/sums*100
    
    x.data<<-cc+bb/2
    y.data<<-sqrt(3)*bb/2

    y0<-51.96152423
     
    temp<-list(
        clssf=list("NULL",use=2:24,rcname=c("quartzolite","quartz-rich granitoid","alk-fsp. granite","syenogranite","monzogranite","granodiorite","tonalite","tonalgabbro","tonaleucrite","alk-fsp quartz syenite","quartz syenite","quartz monzonite","quartz monzodiorite","quartz diorite","quartz gabbro","quartz eucrite","alkali-feldspar syenite","syenite","monzonite","monzodiorite","diorite","gabbroids","eucritoids")),
        polygon1=list("NULL",x=c(77.9/tan(pi/3),100-77.9/tan(pi/3),50,77.9/tan(pi/3)),y=c(77.9,77.9,50*sqrt(3),77.9),col="#00FF0055"),
        
        polygon2=list("NULL",x=c(30,70,100-77.9/tan(pi/3),77.9/tan(pi/3),30),y=c(52,52,77.9,77.9,52),col="#FF000055"),
        
        polygon3=list("NULL",x=c(10,18,34,30,10),y=c(17.3,17.3,52,52,17.3),col="#FF000055"),
        polygon4=list("NULL",x=c(18,34,42,34,18),y=c(17.3,17.3,52,52,17.3),col="#00FF0055"), 
        polygon5=list("NULL",x=c(34,50,50,42,34),y=c(17.3,17.3,52,52,17.3),col="#FF000055"),
        polygon6=list("NULL",x=c(50,62,56,50,50),y=c(17.3,17.3,52,52,17.3),col="#00FF0055"),
        polygon7=list("NULL",x=c(62,74,62,56,62),y=c(17.3,17.3,52,52,17.3),col="#FF000055"),
        polygon8=list("NULL",x=c(74,82,66,62,74),y=c(17.3,17.3,52,52,17.3),col="#00FF0055"),
        polygon9=list("NULL",x=c(82,90,70,66,82),y=c(17.3,17.3,52,52,17.3),col="#FF000055"),
        
        polygon10=list("NULL",x=c(2.5,12,18,10,2.5),y=c(4.3,4.3,17.3,17.3,4.3),col="#00FF0055"),
        polygon11=list("NULL",x=c(12,31,34,18,12),y=c(4.3,4.3,17.3,17.3,4.3),col="#FF000055"),
        polygon12=list("NULL",x=c(31,50,50,34,31),y=c(4.3,4.3,17.3,17.3,4.3),col="#00FF0055"),
        polygon13=list("NULL",x=c(50,64.25,62,50,50),y=c(4.3,4.3,17.3,17.3,4.3),col="#FF000055"),
        polygon14=list("NULL",x=c(64.25,78.5,74,62,64.25),y=c(4.3,4.3,17.3,17.3,4.3),col="#00FF0055"),
        polygon15=list("NULL",x=c(78.5,88,82,74,78.5),y=c(4.3,4.3,17.3,17.3,4.3),col="#FF000055"),
        polygon16=list("NULL",x=c(88,97.5,90,82,88),y=c(4.3,4.3,17.3,17.3,4.3),col="#00FF0055"),
    
        polygon17=list("NULL",x=c(0,10,12,2.5,0),y=c(0,0,4.3,4.3,0),col="#FF000055"),
        polygon18=list("NULL",x=c(10,30,31,12,10),y=c(0,0,4.3,4.3,0),col="#00FF0055"),
        polygon19=list("NULL",x=c(30,50,50,31,30),y=c(0,0,4.3,4.3,0),col="#FF000055"),
        polygon20=list("NULL",x=c(50,65,64.25,50,50),y=c(0,0,4.3,4.3,0),col="#00FF0055"),
        polygon21=list("NULL",x=c(65,80,78.5,64.25,65),y=c(0,0,4.3,4.3,0),col="#FF000055"),
        polygon22=list("NULL",x=c(80,90,88,78.5,80),y=c(0,0,4.3,4.3,0),col="#00FF0055"),
        polygon23=list("NULL",x=c(90,100,97.5,88,90),y=c(0,0,4.3,4.3,0),col="#FF000055"),
        
        
        lines1=list("lines",x=c(30,70),y=c(52,52),col=col1), 
        lines2=list("lines",x=c(10,90),y=c(17.3,17.3),col=col1), 
        lines3=list("lines",x=c(2.5,97.5),y=c(4.3,4.3),col=col1),         
        lines4=list("lines",x=c(45,55),y=c(77.9,77.9),col=col1), 
        lines5=list("lines",x=c(10,34),y=c(0,y0),col=col1), 
        lines6=list("lines",x=c(30,42),y=c(0,y0),col=col1),
        lines7=list("lines",x=c(50,50),y=c(0,y0),col=col1),
        lines8=list("lines",x=c(65,56),y=c(0,y0),col=col1),
        lines9=list("lines",x=c(80,62),y=c(0,y0),col=col1),
        lines10=list("lines",x=c(90,66),y=c(0,y0),col=col1),
       
        # Outline       
        lines20=list("lines",x=c(0,100,50,0),y=c(0,0,sqrt(3)*50,0),col="black") 
    )

    common<-list(
        A=list("text",x=0,y=-5,text="or+ab",adj=0.5),
        B=list("text",x=50,y=sqrt(3)*100/2+3,text="2Q",adj=0.5),
        C=list("text",x=100,y=-5,text="4an",adj=0.5),
        GCDkit=list("NULL",plot.type="ternary",plot.position=39,plot.name="(or+ab)-2Q-4an diagram (Enrique 2018) ")
    )
    
    temp1<-list(        
        text1=list("text",x=50,y=82.3,text="1",col=plt.col[2],cex=0.75),
        text2=list("text",x=50,y=65,text="2",col=plt.col[2],cex=0.75),
        text3=list("text",x=22,y=34.65,text="3",col=plt.col[2],cex=0.75),
        text4=list("text",x=32,y=34.65,text="4",col=plt.col[2],cex=0.75),
        text5=list("text",x=44,y=34.65,text="5",col=plt.col[2],cex=0.75),
        text6=list("text",x=54.5,y=34.65,text="6",col=plt.col[2],cex=0.75),
        text7=list("text",x=63.5,y=34.65,text="7",col=plt.col[2],cex=0.75),
        text8=list("text",x=71,y=34.65,text="8",col=plt.col[2],cex=0.75),
        text9=list("text",x=77,y=34.65,text="9",col=plt.col[2],cex=0.75),
        text10=list("text",x=10,y=10.83,text="10",col=plt.col[2],cex=0.75),
        text11=list("text",x=23,y=10.83,text="11",col=plt.col[2],cex=0.75),
        text12=list("text",x=41,y=10.83,text="12",col=plt.col[2],cex=0.75),
        text13=list("text",x=56,y=10.83,text="13",col=plt.col[2],cex=0.75),
        text14=list("text",x=69,y=10.83,text="14",col=plt.col[2],cex=0.75),
        text15=list("text",x=80.3,y=10.83,text="15",col=plt.col[2],cex=0.75),
        text16=list("text",x=89.3,y=10.83,text="16",col=plt.col[2],cex=0.75),
        text17=list("text",x=6,y=2.615,text="17",col=plt.col[2],cex=0.75),
        text18=list("text",x=20.5,y=2.615,text="18",col=plt.col[2],cex=0.75),
        text19=list("text",x=40.5,y=2.615,text="19",col=plt.col[2],cex=0.75),
        text20=list("text",x=57,y=2.615,text="20",col=plt.col[2],cex=0.75),
        text21=list("text",x=72,y=2.615,text="21",col=plt.col[2],cex=0.75),
        text22=list("text",x=84.5,y=2.615,text="22",col=plt.col[2],cex=0.75),
        text23=list("text",x=94,y=2.615,text="23",col=plt.col[2],cex=0.75)    
   )
    
    temp<-c(temp,common)        
    if(getOption("gcd.plot.text"))temp<-c(temp,temp1)

    sheet<<-list(demo=list(fun="plot",call=list(xlim=c(-3,103),main=annotate(temp$GCDkit$plot.name),ylim=c(-10,103),xlab="",ylab="",bg="transparent",fg="black",asp=1,axes=FALSE),template=temp))
# "(or+ab)-2Q-4an diagram (Enrique 2018)"
}
